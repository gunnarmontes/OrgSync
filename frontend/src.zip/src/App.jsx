export default function App() {
  return (
    <div className="h-screen flex items-center justify-center bg-green-500">
      <h1 className="text-4xl font-bold text-white">
        Tailwind is working! 🎉
      </h1>
    </div>
  );
}
