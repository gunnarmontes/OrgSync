import SearchRecipe from "../components/SearchRecipe";

export default function Home() {
  return (
    <div>
      <h1>Welcome to the Dashbpard App!</h1>
      
    </div>
  );
}